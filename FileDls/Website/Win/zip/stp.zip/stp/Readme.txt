Sort-Those-Pics by Gasco Solutions (Pty) Ltd

Purpose:
Sort-Those-Pics is desinged to assist you in organizing large groups of photos into individual folders by year, month and date.

Usage:
In order to make use of the features of Sort-Those-Pics, place all the photos that need organizing into a single folder.
Sort-Those-Pics is not designed to search through subfolders, so make sure all the photos are in one single folder.
Use the setup feature in Sort-Those-Pics to select the format of the folders that will be created.

Overview:
Use Sort-Those-Pics and select the folder where you have placed all the photos that need organizing.
Select the option to create the folders.
Folders will be created based on the date when each photo was taken.
Each photo will then be moved to the corresponding folder.
Sort-Those-Pics is especially useful when taking a large number of photos from multiple devices and organizing them into folders based on the date when each photo was taken.

System requirements:
Sort-Those-Pics is designed for a Windows-based PC. It was designed to be used on a PC running Windows 7 and later.
It may run on other Operating Systems, but it cannot be guaranteed nor is it supported.